<template>
  <div @click="toggleShow()">
    <footer>{{title}} <span v-if="isShow">by</span></footer>
  </div>
</template>

<script>
export default {
  data() {
    return {
      isShow: true
    }
  },
  props: {
    title: {
      default: 'Rightcopy'
    }
  },
  methods: {
    toggleShow() {
      this.isShow = !this.isShow
    }
  }
}
</script>

<style lang="scss">
</style>
