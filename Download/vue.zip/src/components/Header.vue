<template>
  <header><h1>Vue.js Study</h1></header>
</template>

<script>
export default {
}
</script>

<style lang="scss">
</style>
